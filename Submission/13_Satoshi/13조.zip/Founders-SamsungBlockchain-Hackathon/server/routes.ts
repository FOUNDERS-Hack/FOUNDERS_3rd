const nextRoutes = require("next-routes");
export const routes = (module.exports = nextRoutes());

routes.add("TestPage", "/test-page");
