export const STORE = {
  globalStore: "globalStore",
};