const HEADER = {
  mainNavigation: [
    { href: "/TestPage", asPath: "/TestPage", name: "테스트페이지" },
    { href: "/TransactionPage", asPath: "/TransactionPage", name: "트랜잭션" }
  ]
};

export {
  HEADER,
};
