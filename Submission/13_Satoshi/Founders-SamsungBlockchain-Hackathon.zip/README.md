# nextjs-semantic
> Next.js + Semantic UI React + Styled Components + Typescript + caver-js(Klaytn)

## Setup(to be updated)
1. `yarn`
2. `yarn run dev`
