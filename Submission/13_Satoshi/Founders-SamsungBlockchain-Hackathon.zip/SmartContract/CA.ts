const CountContractCA = "0x877CbbdDc944B7d90Ea3E502ab4a4e542549B7E6";

export { CountContractCA };
